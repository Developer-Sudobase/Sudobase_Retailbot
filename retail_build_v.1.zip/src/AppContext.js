import React, { useState } from "react";
import useLoginAttempts from "./hooks/useLoginAttempts";
import useCognito from "./hooks/useCognito";

export const AppContext = React.createContext();

const AppContextProvider = ({ children }) => {

    const [isModelOpen, setIsModelOpen] = useState(false);

    const { getLoginAttempts, incrementLoginAttempts, resetLoginAttempts } = useLoginAttempts();


    const toggleModelState = () => {
        setIsModelOpen(!isModelOpen)
        console.log('clicked');
    }

    const {
        signIn,
        signOut,
        register,
        deleteAccount,
        verifyAccount,
        registrationStatus,
        isLoggedIn,
        username,
        email,
        resetPassword,
        confirmPassword,
        cognitoUser,
        currentUser,
        userSub,
      } = useCognito({  });

    return (
        <AppContext.Provider
            value={{
                isModelOpen,
                setIsModelOpen,
                toggleModelState,
                signIn,
                signOut,
                register,
                deleteAccount,
                verifyAccount,
                registrationStatus,
                isLoggedIn,
                username,
                email,
                resetPassword,
                confirmPassword,
                getLoginAttempts,
                incrementLoginAttempts,
                resetLoginAttempts,
                cognitoUser,
                currentUser,
                userSub,
            }}
        >
            {children}
        </AppContext.Provider>
    );

};
export default AppContextProvider;