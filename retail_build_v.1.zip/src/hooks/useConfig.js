const useConfig = () => {
    const appConfig = window.appConfig;
    return appConfig;
  };

  export default useConfig;
  