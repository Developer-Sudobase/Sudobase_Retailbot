import { Fab, makeStyles } from '@material-ui/core'
import React, { useEffect, useState } from 'react';
import Draggable from 'react-draggable';
import { Chat } from '@material-ui/icons';
import { Widget, addResponseMessage, addUserMessage  } from 'react-chat-widget';
import 'react-chat-widget/lib/styles.css';
import './FloatButton.css';

const useStyles = makeStyles((theme) => ({
    float: {
        position: 'absolute',
        right: 20,
        bottom: 25,
        [theme.breakpoints.down('xs')]: {
            height: '80vh',
        },
    }
}));


const handleNewUserMessage = (newMessage) => {
    console.log(`New message incoming! ${newMessage}`);

    // Now send the message throught the backend API
  };

const FloatButton = () => {
    const classes = useStyles()
    
useEffect(() => {
    addResponseMessage('Welcome to SleekBuys!');
  }, []);


    return (

        <div className={classes.float}>
           {/* <Fab color="secondary" aria-label="send"><Chat/></Fab> */}
           <Widget handleNewUserMessage={handleNewUserMessage} title="SleekBuys" subtitle={false} fullScreenMode={false}/>
        </div>

    )
}

export default FloatButton
