import React from 'react';
import SendIcon from '@material-ui/icons/Send';
import { IconButton, makeStyles } from '@material-ui/core';
import { MicNone } from '@material-ui/icons';

const useStyles = makeStyles((theme) => ({
    form: {
        position: "relative",
        width: `100%`,
        display: 'flex',
        justifyContent: 'center'
    },
    querybox: {
        width: `100%`,
        [theme.breakpoints.down('xs')]: {
            display: 'none',
        },
    },
    button: {
        position: 'relative',
        right: 56
    },
    mic: {
        position: 'relative',
        right: 40,
        fontSize: 24,
        color: '#fff'
    },
    input: {
        width: '50%',
        borderRadius: 24,
        backgroundColor: 'white',
        border: '1px solid transparent',
        fontSize: 20,
        boxShadow: '0 2px 5px 1px rgb(64 60 67 / 16%)',
        padding: '6px 0px 6px 14px',
        '&:focus': {
          borderColor: '#80bdff',
          outline: 'none !important'
        },
    }
}))

const submitHandler = (e) => {
    e.preventDefault();
    e.target.reset();
}

const QueryBox = () => {
    const classes = useStyles()
    return (
        <div className={classes.querybox}>  
            <form className={classes.form} onSubmit={(e) => submitHandler(e)}>
                <input type="text" placeholder="Type Here" className= {classes.input}/>
                <IconButton className={classes.button} type="submit"><SendIcon/></IconButton>
                <IconButton className={classes.mic} ><MicNone fontSize="large"/></IconButton>
            </form>
        </div>
    )
}

export default QueryBox
