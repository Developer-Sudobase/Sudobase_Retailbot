import React from 'react'

const Sidebar = () => {
    return (
        <div className="sidebar">
            
        </div>
    )
}

export default Sidebar
