import { Button, makeStyles } from '@material-ui/core'
import React from 'react';
import data from '../../utilities/data.json';

const useStyles = makeStyles((theme) => ({
    root: {
      padding: '5px'
    },
    button: {
        borderRadius: '24px',
        margin: theme.spacing(1),
        '&:hover': {
            backgroundColor: 'rgb(255,226,104)',
            color: '#333',
            }
        }
  }));

const Buttons = () => {
    const classes = useStyles();
    return (
        <>
        { data.Buttons.map ((button , i) => {
        return (<div className={classes.root} key={i}>
            <Button variant="outlined" color="primary" className={classes.button}>
                {button.Text1}
            </Button>
            <Button variant="outlined" color="primary" className={classes.button}>
               {button.Text2}
            </Button>
            <Button variant="outlined" color="primary" className={classes.button}>
               {button.Text3}
            </Button>
        </div>)
        })}
        </>
    )
}

export default Buttons
