export const products = {
    details: [
      {
        "_id": "1",
        "title": "Nike Shoes",
        "src": [
            "https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixid=MXwxMjA3fDB8MHxzZWFyY2h8Mnx8c2hvZXN8ZW58MHx8MHw%3D&ixlib=rb-1.2.1&w=1000&q=80",
            "http://sneakerfits.com/wp-content/uploads/2021/02/ua-project-rock-3-training-shoe-hi-vis-yellow-3.jpg",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDZRNqItce-JdL6nABAQAruIIgl8YjrzOkJnUp4r8mZCLrDxN5TpRsk1_tueWsZIrBdw8&usqp=CAU",
            "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/eb1c2ded-ae08-494b-81ae-3aaa583f067d/air-max-pre-day-shoes-hlv9tD.png"
          ],
        "description": "Choose your product",
        "content": "Welcome to SleekBuys",
        "price": 23,
        "colors":["red","black","crimson","teal"],
        "count": 1
      }
    ],
    index: 0
  };