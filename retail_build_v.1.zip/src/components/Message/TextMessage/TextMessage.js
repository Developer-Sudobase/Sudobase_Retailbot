import { makeStyles, Typography } from '@material-ui/core';
import React from 'react';

const useStyles = makeStyles((theme) => ({

}))
const TextMessage = (message) => {
    const classes = useStyles();
    return (
        <div message={message}>
            <Typography variant="h5">TextTextTextTextTextTextTextTextText</Typography>
        </div>
    )
}

export default TextMessage
