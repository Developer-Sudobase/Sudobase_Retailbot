import React from 'react';
import { makeStyles } from '@material-ui/core'
import ProductsUi from '../Products/ProductUI/ProductsUi';
import Buttons from '../Products/ButtonUi/Buttons';
import DetailView from '../Products/DetailView/DetailView';

const useStyles = makeStyles((theme) => ({
    message: {
        display: 'flex',
        borderRadius: '16px 0 16px 16px',
        padding: '0.5rem',
        position: 'relative',
        backgroundColor: 'rgb(76,129,194)',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
        marginLeft: 'auto',
        color: '#fff'
    },
    cards: {
        display: 'flex',
    },
    view: {
        maxWidth: '1200px',
        width: '100%',
        margin: '100px auto',
        boxShadow: '0 0 5px #ccc',
    }
}))

const Message = () => {
    const classes = useStyles()
    return (
        <>
        <div className={classes.cards}><ProductsUi/></div>
        <div className={classes.button}><Buttons/></div>
        <div className={classes.view}><DetailView/></div>
        </>
    )
}

export default Message
