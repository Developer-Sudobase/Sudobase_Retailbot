import { Grid } from '@material-ui/core';
import '../App.css';
import FloatButton from '../components/FloatButton/FloatButton';
import Header from '../components/Header/Header';
import MessageContainer from '../components/MessageContainer/MessageContainer';
import SignInForm from '../components/SignInForm/SignInForm'

function RetailApp() {
  return (
    <div className="RetailApp">
      <Grid container direction='column'>
        <Grid><Header/></Grid>
        <Grid item container xs={12}>
          <MessageContainer/>
          <FloatButton/>
          {/* <SignInForm/> */}
        </Grid>
      </Grid>
    </div>
  );
}

export default RetailApp;
