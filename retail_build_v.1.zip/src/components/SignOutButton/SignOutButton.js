import React from "react";
import { ExitToApp } from "@material-ui/icons";
import { IconButton, makeStyles } from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
    signout: {
        color: '#fff',
        position: 'absolute',
        right: '10px',
    }
}))

const SignOutButton = ({ signOutHandler }) => {
    const classes = useStyles();

  return (
    <IconButton className={classes.signout} onClick={() => signOutHandler()}>
      <ExitToApp/>
    </IconButton>
  );
};

export default SignOutButton;
