import { makeStyles } from '@material-ui/core';
import React from 'react';
import Message from '../Message/Message';

const useStyles = makeStyles((theme) => ({
    messagecontainer: {
        height: 'calc(100vh - 64px)',
        width: '100%',
        position: 'relative',
        backgroundColor: '#fff',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'auto',
        padding: '0.5rem'
    },
}))

const MessageContainer = () => {
    const classes = useStyles()
    return (
        <div className={classes.messagecontainer}>
            <Message/>
        </div>
    )
}

export default MessageContainer
