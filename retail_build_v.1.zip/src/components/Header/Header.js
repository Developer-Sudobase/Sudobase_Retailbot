import React, { useContext } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { AppBar, Toolbar, Typography } from '@material-ui/core';
import QueryBox from '../QueryBox/QueryBox';    
import { ShoppingBasket } from '@material-ui/icons';
import SignOutButton from '../SignOutButton/SignOutButton';
import { AppContext } from '../../AppContext';

const useStyles = makeStyles((theme) => ({
    root: {
        boxShadow: '0px 0px',
        flexGrow: 1,
    },
    appbar: {
        color: 'secondary',
    },
    logoimg: {
        width: '15%',
        paddingTop: '5px',
        [theme.breakpoints.down('xs')]: {
            width: '30%',
        },
    }
}))

const Header = () => {

    const classes = useStyles()

    const { signOut, username } = useContext(AppContext)

    const signOutHandler = () => {
        signOut();
      };

    return (
            <AppBar position="static" className={classes.root}>
                <Toolbar className={classes.appbar}>
                <img className={classes.logoimg}
                    src={process.env.PUBLIC_URL + '/images/sleekbuys_logo.png'}
                    alt="SleekBuys"
                 />
                    <QueryBox/>
                    <SignOutButton signOutHandler={() => {signOutHandler();}}/>
                </Toolbar>
            </AppBar>      
    )
}

export default Header
